export const AuthenticationConfiguration = {
	publicRoutes: [
		['GET', '/api/def'],
		['POST', '/api/user/login'],
		['POST', '/api/user'],
	],
}
