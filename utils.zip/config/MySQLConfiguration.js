export const MySQLConfiguration = {
	url: 'localhost',
	user: 'root',
	password: 'thmpv005',
}
