export const MongoDBConfiguration = {
	url: 'mongodb+srv://michel:thmpv005@cluster0.7cfsqrl.mongodb.net/?retryWrites=true&w=majority',
	database: 'meuOrcamentoOnline',
}
