export const ContentConfiguration = {
	mainFolder: './content',
}
