export const GeneralConfiguration = {
	port: 8080,
	databaseType: 'mongo',
}
